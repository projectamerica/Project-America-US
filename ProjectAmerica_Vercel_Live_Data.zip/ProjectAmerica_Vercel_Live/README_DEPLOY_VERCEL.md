# Project America — Vercel deployment

This package is adapted for Vercel: static site files are at the repository root and `/api/*` requests are handled by a Vercel Node serverless function that reuses the Project America backend in `src/index.js`. The Cloudflare `wrangler.jsonc` is intentionally not included.

## Deploy
1. Upload and extract **the contents** of this ZIP into the root of a GitHub repository (not the ZIP as a single file).
2. In Vercel choose **Add New → Project**, import that GitHub repository, and deploy.
3. Framework Preset: **Other**. Build Command: leave empty. Output Directory: `.` (or leave default if Vercel detects static files). Install Command can be left empty; there are no runtime dependencies.
4. After deployment, test `/api/health`, then `/api/us-election-results?mode=health`, `/api/us-election-results?mode=catalog`, and `/api/us-election-results?mode=race&id=87275`.

## Backend endpoints retained
- `/api/health`
- `/api/us-election-results?mode=health|catalog|race&id=...|senate-ids`
- `/api/early-vote?state=PA&category=returned`
- `/api/house-baseline`
- `/api/share?d=...`

## Important
The backend code and live CivicAPI fetch logic are included. Actual upstream CivicAPI availability, race IDs, and returned data have **not** been verified by deployment in this package. The `mode=health` endpoint distinguishes Vercel function health from CivicAPI health. If CivicAPI requires credentials or blocks the request, the live test will show that; no fake election results are substituted.
