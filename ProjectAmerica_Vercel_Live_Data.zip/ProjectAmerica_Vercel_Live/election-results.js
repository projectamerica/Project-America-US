/* Project America 2026 Election Results. Isolated from existing simulator state. */
(()=>{'use strict';
 const root=document.getElementById('resultsLab');if(!root)return;
 const $=id=>document.getElementById(id),API='/api/us-election-results';
 const codeToName=Object.fromEntries(Object.entries(window.postal||{}).map(([k,v])=>[v,k]));
 const STATES=window.STATES||{}; // const bindings in original index script aren't window properties; fall back to embedded mapping.
 const POSTAL={AL:'01',AK:'02',AZ:'04',AR:'05',CA:'06',CO:'08',CT:'09',DE:'10',DC:'11',FL:'12',GA:'13',HI:'15',ID:'16',IL:'17',IN:'18',IA:'19',KS:'20',KY:'21',LA:'22',ME:'23',MD:'24',MA:'25',MI:'26',MN:'27',MS:'28',MO:'29',MT:'30',NE:'31',NV:'32',NH:'33',NJ:'34',NM:'35',NY:'36',NC:'37',ND:'38',OH:'39',OK:'40',OR:'41',PA:'42',RI:'44',SC:'45',SD:'46',TN:'47',TX:'48',UT:'49',VT:'50',VA:'51',WA:'53',WV:'54',WI:'55',WY:'56'};
 const NAMES={AL:'Alabama',AK:'Alaska',AZ:'Arizona',AR:'Arkansas',CA:'California',CO:'Colorado',CT:'Connecticut',DE:'Delaware',DC:'District of Columbia',FL:'Florida',GA:'Georgia',HI:'Hawaii',ID:'Idaho',IL:'Illinois',IN:'Indiana',IA:'Iowa',KS:'Kansas',KY:'Kentucky',LA:'Louisiana',ME:'Maine',MD:'Maryland',MA:'Massachusetts',MI:'Michigan',MN:'Minnesota',MS:'Mississippi',MO:'Missouri',MT:'Montana',NE:'Nebraska',NV:'Nevada',NH:'New Hampshire',NJ:'New Jersey',NM:'New Mexico',NY:'New York',NC:'North Carolina',ND:'North Dakota',OH:'Ohio',OK:'Oklahoma',OR:'Oregon',PA:'Pennsylvania',RI:'Rhode Island',SC:'South Carolina',SD:'South Dakota',TN:'Tennessee',TX:'Texas',UT:'Utah',VT:'Vermont',VA:'Virginia',WA:'Washington',WV:'West Virginia',WI:'Wisconsin',WY:'Wyoming'};
 const SENATE_2026=new Set('AL AK AR CO DE FL GA ID IL IA KS KY LA ME MA MI MN MS MT NE NH NJ NM NC OH OK OR RI SC SD TN TX VA WV WY'.split(' '));
 const GOVERNOR_2026=new Set('AL AK AZ AR CA CO CT FL GA HI ID IL IA KS ME MD MA MI MN NE NV NH NM NY OH OK OR PA RI SC SD TN TX VT WI WY'.split(' '));
 const reverse=Object.fromEntries(Object.entries(POSTAL).map(([k,v])=>[v,k]));
 const F=(x)=>String(x??'').padStart(5,'0'),fmt=n=>Number(n||0).toLocaleString('en-US'),safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const pick=(o,...keys)=>{for(const k of keys)if(o&&o[k]!=null&&o[k]!=='')return o[k];return null};
 const arr=v=>Array.isArray(v)?v:Array.isArray(v?.data)?v.data:Array.isArray(v?.results)?v.results:[];
 const party=x=>{const p=String((x&&typeof x==='object'?(x.abbreviation||x.code||x.name||x.party_name):x)||'').trim();return /democrat|^dem$|^d$/i.test(p)?'D':/republican|^rep$|^gop$|^r$/i.test(p)?'R':p.length<=8&&p?p.toUpperCase():'O'};
 const tint={D:'#3385ee',R:'#e45c67',O:'#c9ac70'};
 // Map shading: exact copy of the Swingometer scale (index.html color(m,'margin')): discrete bins on the two-party D-minus-R margin in points; no-data gray #465368.
 const SWING_NO_DATA='#465368';
 const swingColor=m=>!Number.isFinite(m)?SWING_NO_DATA:m>=30?'#19498b':m>=15?'#397bcb':m>=5?'#9ac5ec':m>=0?'#cbdff3':m>=-5?'#f1c5c5':m>=-15?'#efa5a3':m>=-30?'#d65457':'#8e202c';
 const SWING_LEGEND=[['#19498b','D +30 or more'],['#397bcb','D +15 to 30'],['#9ac5ec','D +5 to 15'],['#cbdff3','D +0 to 5'],['#f1c5c5','R +0 to 5'],['#efa5a3','R +5 to 15'],['#d65457','R +15 to 30'],['#8e202c','R +30 or more'],[tint.O,'Other / independent leading'],[SWING_NO_DATA,'Not reported / no data']].map(([c,t])=>'<span><i class="er-dot" style="background:'+c+'"></i>'+t+'</span>').join('')+'<span style="opacity:.8">Shading = two-party D–R margin (Swingometer scale)</span>';
 // Vote-reporting percentage: only what civicAPI supplies. Never estimated, defaulted or back-filled.
 const PCT_KEYS=['percent_reporting','percentReporting','percent_reported','percentReported','pct_reporting','pctReporting','reporting_percent','reportingPercent','reporting_pct','percentage_reporting','precincts_reporting_percent','precinctsReportingPercent','percent_in','pct_in'];
 const PRECINCT_PAIRS=[['precincts_reporting','precincts_total'],['precincts_reported','precincts_total'],['precincts_reporting','total_precincts'],['precinctsReporting','precinctsTotal'],['precincts_in','precincts_total'],['reporting_precincts','total_precincts']];
 const toNum=v=>{if(v==null||v===''||typeof v==='boolean')return null;const n=typeof v==='string'?parseFloat(v.replace('%','').trim()):Number(v);return Number.isFinite(n)?n:null};
 const regionMemo=new WeakMap();
 const raceId=r=>String(pick(r,'id','race_id','raceId','raceid')||'');
 let backgroundEpoch=0;let category='senate',catalog=[],catalogError='',catalogLoaded=false,loading=false,topo=null,states=[],counties=[],districts=[],selectedState='',selectedRace=null,selectedCounty=null,detailCache=new Map(),requestSeq=0,refreshTimer=null,loadMapPromise=null;
 const raceList=()=>catalog.filter(r=>r.type===category&&(category==='senate'?SENATE_2026:GOVERNOR_2026).has(getRaceState(r)));
 const eligible=code=>(category==='senate'?SENATE_2026:GOVERNOR_2026).has(code);
 const districtGeo=f=>{const p=f.properties||{};const raw=String(p.GEOID||p.GEOIDFQ||p.GEOID20||p.GEOIDFQ20||'').replace(/^.*US/,'');if(/^\d{4}$/.test(raw))return raw;const st=String(p.STATE||p.STATEFP||'').padStart(2,'0'),cd=String(p.CD119||p.CD120||p.CD118||p.CD||'').padStart(2,'0');return /^\d{2}$/.test(st)&&/^\d{2}$/.test(cd)?st+cd:raw};
 const stateRaceOptions=code=>raceList().filter(r=>getRaceState(r)===code);
 
 function nameState(code){return NAMES[code]||code||'United States'}
 function getRaceState(r){if(NAMES[r.state])return r.state;if(NAMES[String(r.state||'').toUpperCase()])return String(r.state).toUpperCase();const raw=r.raw||{},title=[r.title,r.district,raw.province,raw.state,raw.location].filter(v=>typeof v==='string').join(' ');const match=Object.entries(NAMES).find(([c,n])=>new RegExp('\\b'+n+'\\b','i').test(title));if(match)return match[0];const abbrev=title.match(/\\b([A-Z]{2})[- ](?:0?[1-9]|[1-4][0-9]|AL|At Large|Senate|Governor)\\b/i)||title.match(/(?:^|[ (])([A-Z]{2})(?:[ )-]|$)/);return abbrev&&POSTAL[abbrev[1].toUpperCase()]?abbrev[1].toUpperCase():''}
 function districtKey(r){const text=[r.district,r.title,r.raw?.district_name,r.raw?.district_number,r.raw?.congressional_district].filter(Boolean).join(' ');let m=text.match(/\b([A-Z]{2})[- ]?(AL|AT LARGE|\d{1,2})\b/i);if(m&&POSTAL[m[1].toUpperCase()])return POSTAL[m[1].toUpperCase()]+(m[2].toUpperCase().startsWith('A')?'00':m[2].padStart(2,'0'));
 m=text.match(/\b(?:district|CD|house)\s*(\d{1,2})\b/i);const state=getRaceState(r);if(state&&m)return POSTAL[state]+m[1].padStart(2,'0');
 const raw=String(r.district||r.raw?.district_number||'').trim();if(state&&/^\d{1,2}$/.test(raw))return POSTAL[state]+raw.padStart(2,'0');
 if(state&&/at.large|at large/i.test(text))return POSTAL[state]+'00';return null}
 function selectRaceForState(code){const options=stateRaceOptions(code);return options[0]||null}
 function stateHasRace(code){return eligible(code)}
 function readCandidates(raw){
  const roots=[raw,raw?.race,raw?.data,raw?.data?.race,raw?.result,raw?.race_info,raw?.race?.race_info,raw?.data?.race_info,raw?.election,raw?.data?.election,raw?.contest,raw?.data?.contest,raw?.results?.race,raw?.results?.election].filter(Boolean);
  let candidates=[];
  for(const body of roots){
   for(const key of ['candidates','candidate_results','results','options','contestants','choices','ballot_options','race_candidates','candidate_list','candidateList','ballot_choices','vote_options','candidateVotes','ballotCandidates','candidates_list','candidate_data','vote_totals','entries']){
    const value=body?.[key];if(Array.isArray(value)&&value.length){candidates=value;break}
    if(value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length){
     const items=Object.entries(value).map(([id,c])=>typeof c==='object'&&c?{id,...c}:{id,name:id,votes:c});
     if(items.some(c=>c.name||c.candidate_name)){candidates=items;break}
    }
   }
   if(!candidates.length&&Array.isArray(body?.ballot?.candidates))candidates=body.ballot.candidates;
   if(candidates.length)break;
  }
  if(!candidates.length&&raw&&typeof raw==='object'){
   const visited=new Set();const queue=[{v:raw,depth:0}];
   while(queue.length&&!candidates.length){const {v,depth}=queue.shift();if(!v||typeof v!=='object'||visited.has(v)||depth>7)continue;visited.add(v);
    for(const [key,val] of Object.entries(v)){if(Array.isArray(val)&&/candidates|contestants|choices|options|ballot/i.test(key)&&val.some(x=>x&&typeof x==='object'&&(x.name||x.candidate_name||x.full_name||x.candidate?.name))){candidates=val;break}
     if(val&&typeof val==='object'&&!Array.isArray(val)&&!/county|precinct|region|geographic/i.test(key))queue.push({v:val,depth:depth+1});}
   }
  }
  return candidates.map((c,i)=>{
   if(typeof c==='string')c={name:c};
   const candidate=c.candidate&&typeof c.candidate==='object'?c.candidate:c.person&&typeof c.person==='object'?c.person:c;
   const voteValue=pick(c,'votes','vote_count','total_votes','totalVotes','voteTotal','total','vote_count_total','votes_total','voteCount','vote_total','num_votes','ballots');
   return {id:String(pick(candidate,'id','candidate_id','candidateId')||i),name:String(pick(candidate,'name','candidate_name','full_name','display_name','candidateName','ballot_name','label','candidate_full_name','displayName','candidateName','person_name','option_name')||pick(c,'candidate','name','option_name')||'Candidate '+(i+1)),party:party(pick(candidate,'party','party_name','party_code','affiliation','political_party','partyName','party_abbreviation','party_short','party_label')||pick(c,'party','party_name','party_abbreviation','party_short')),votes:Number(voteValue??0),reported:voteValue!=null};
  }).filter(c=>Number.isFinite(c.votes)&&c.votes>=0);
 }
 function regionRows(raw){if(raw&&typeof raw==='object'&&regionMemo.has(raw))return regionMemo.get(raw);const rows=regionRowsRaw(raw);if(raw&&typeof raw==='object')regionMemo.set(raw,rows);return rows}
 function regionRowsRaw(raw){const body=raw?.race||raw?.data?.race||raw?.data||raw||{};const regions=pick(body,'region_results','regions','county_results','counties','geographic_results');if(!regions)return [];
  const items=Array.isArray(regions)?regions:Object.entries(regions).map(([name,value])=>({name,...(typeof value==='object'&&value?value:{votes:value})}));
  return items.map(item=>{
   const name=String(pick(item,'name','region_name','county','county_name','label')||'');const fips=String(pick(item,'fips','geoid','county_fips','region_fips')||'');
   let votes=readCandidates(item);
   // Some civicAPI geographic payloads store candidate votes as keyed objects rather than arrays.
   if(!votes.length){const byCandidate=pick(item,'candidate_votes','candidate_results','results','votes');if(byCandidate&&typeof byCandidate==='object'&&!Array.isArray(byCandidate)){
    const national=readCandidates(raw),lookup=new Map(national.map(c=>[c.id,c]));
    votes=Object.entries(byCandidate).map(([key,v])=>{const n=Number(typeof v==='object'?pick(v,'votes','total','vote_count'):v);const c=lookup.get(String(key))||national.find(x=>x.name.toLowerCase()===key.toLowerCase());return {id:key,name:c?.name||key,party:c?.party||'O',votes:n}}).filter(c=>Number.isFinite(c.votes));
   }}
   const total=Number(pick(item,'total_votes','total')||votes.reduce((a,c)=>a+c.votes,0));
   return {name,fips,votes,total,reporting:reportingOf(item)};
  }).filter(r=>r.name||r.fips);
 }
 function reportingOf(o){if(!o||typeof o!=='object'||Array.isArray(o))return null;
  for(const k of PCT_KEYS){const n=toNum(o[k]);if(n!=null&&n>=0&&n<=100)return {pct:n}}
  if(o.reporting&&typeof o.reporting==='object'&&!Array.isArray(o.reporting)){for(const k of ['percent','percentage','pct']){const n=toNum(o.reporting[k]);if(n!=null&&n>=0&&n<=100)return {pct:n}}}
  for(const [a,b] of PRECINCT_PAIRS){const x=toNum(o[a]),y=toNum(o[b]);if(x!=null&&y!=null&&y>0&&x>=0&&x<=y)return {pct:100*x/y,counts:[x,y]}}
  return null}
 function raceReporting(raw){if(!raw||typeof raw!=='object')return null;for(const body of [raw,raw.race,raw.data,raw.data?.race,raw.race?.data,raw.race?.race_info,raw.race_info,raw.data?.race_info,raw.result,raw.election,raw.data?.election,raw.contest,raw.data?.contest,raw.results?.race,raw.results?.election]){const r=reportingOf(body);if(r)return r}return null}
 function fmtReporting(r){if(!r)return null;const p=r.pct>=100?100:Math.floor(r.pct*10+1e-9)/10;let t=(Number.isInteger(p)?p:p.toFixed(1))+'%';if(r.counts)t+=' ('+fmt(r.counts[0])+' of '+fmt(r.counts[1])+' precincts)';return t}
 function countyReportingHtml(raw){if(!selectedRace||!raw||!selectedState)return '';const rows=regionRows(raw).filter(r=>r.name||r.fips).sort((a,b)=>String(a.name||a.fips).localeCompare(String(b.name||b.fips)));
  if(!rows.length)return '<div class="er-sub er-rpt-note">County-level results and reporting are not provided by civicAPI for this race yet.</div>';
  const have=rows.filter(r=>r.reporting).length;
  return '<details class="er-rpt"><summary>County reporting · '+have+' of '+rows.length+' areas provide a percentage</summary><div class="er-rpt-scroll"><table><thead><tr><th>County / equivalent</th><th>Reporting</th><th>Votes</th></tr></thead><tbody>'+rows.map(r=>'<tr><td>'+safe(r.name||r.fips)+'</td><td>'+(fmtReporting(r.reporting)||'Not provided')+'</td><td>'+(r.total?fmt(r.total):'—')+'</td></tr>').join('')+'</tbody></table></div></details>'}
 function reportingLine(r){const rp=fmtReporting(raceReporting(detailCache.get(r.id)));return '<small style="display:block;opacity:.72;margin-top:2px">'+(detailCache.has(r.id)?(rp?rp+' reporting':'Reporting % not provided by civicAPI'):'Reporting % loading…')+'</small>'}
 function getRegion(f){const id=F(f.id),name=String(f.properties?.name||'').toLowerCase().replace(/\s+(county|parish|borough|census area|municipality)$/,'').trim();const list=regionRows(detailCache.get(raceId(selectedRace))||{});return list.find(r=>r.fips&&F(r.fips)===id)||list.find(r=>r.name.toLowerCase().replace(/\s+(county|parish|borough|census area|municipality)$/,'').trim()===name)||null}
 function leader(votes){const ordered=[...votes].sort((a,b)=>b.votes-a.votes);const total=ordered.reduce((a,c)=>a+c.votes,0);if(!total||!ordered.length)return {color:SWING_NO_DATA,margin:null};const margin=ordered.length>1?100*(ordered[0].votes-ordered[1].votes)/total:100;const lp=ordered[0].party;let color=tint.O;if(lp==='D'||lp==='R'){const d=votes.filter(c=>c.party==='D').reduce((a,c)=>a+c.votes,0),r=votes.filter(c=>c.party==='R').reduce((a,c)=>a+c.votes,0);color=swingColor(100*(d-r)/(d+r))}return {color,margin,party:lp};}
 function badge(m){return m==null?'Not reported':m.party==='D'?'D +'+m.margin.toFixed(1):m.party==='R'?'R +'+m.margin.toFixed(1):'Lead +'+m.margin.toFixed(1)}
 function summaryVotes(raw){return readCandidates(raw)}
 function candidatesForRace(r,raw){const detailed=summaryVotes(raw||{});if(detailed.length)return detailed;
  const fallback=readCandidates(r?.raw||{}).map(c=>({...c,reported:false}));
  return fallback;}
 function raceForDistrict(key){return raceList().find(r=>districtKey(r)===key)||null}
 function stateRaceResults(code){const rr=stateRaceOptions(code);return rr.length===1?rr[0]:rr[0]||null}
 
 async function request(url){const response=await fetch(url,{cache:'no-store'});let data;try{data=await response.json()}catch{throw Error('Server returned an invalid response')}if(!response.ok||data?.error)throw Error(data?.error||'HTTP '+response.status);return data}
 async function loadCatalog(force=false){if(loading)return;loading=true;$('erStatus').textContent='Connecting to civicAPI · 2026 general election…';try{const data=await request(API+'?mode=catalog'+(force?'&refresh='+Date.now():''));catalog=(data.races||[]).filter(r=>['senate','governor'].includes(r.type));catalogError=data.warning||'';catalogLoaded=true;warmCategory();$('erUpdated').textContent='Catalog checked '+new Date().toLocaleTimeString();$('erStatus').textContent=catalogError?catalog.length+' configured/discovered races loaded · '+catalogError:catalog.length+' races discovered · civicAPI · November 3, 2026';}catch(e){catalogError=e.message;$('erStatus').textContent='civicAPI catalog unavailable: '+e.message}finally{loading=false;render();}}
 async function warmCategory(){
  // Progressive map coloring. Four concurrent fetches; no artificial vote values.
  const epoch=++backgroundEpoch;const items=(category==='senate'?catalog.filter(r=>r.type==='senate'):raceList()).filter(r=>!detailCache.has(r.id));let cursor=0;
  async function worker(){while(epoch===backgroundEpoch&&cursor<items.length){const r=items[cursor++];try{const data=await request(API+'?mode=race&id='+encodeURIComponent(r.id));if(epoch!==backgroundEpoch)return;detailCache.set(r.id,data);if(cursor%6===0){drawMap();render()}}catch(e){/* An unavailable race stays neutral. */}
    await new Promise(resolve=>setTimeout(resolve,220));
  }}
  await Promise.all(Array.from({length:4},worker));if(epoch===backgroundEpoch){drawMap();render()}
 }
 async function loadMaps(){if(loadMapPromise)return loadMapPromise;loadMapPromise=(async()=>{
  try{const res=await fetch('https://cdn.jsdelivr.net/npm/us-atlas@3/counties-10m.json');if(!res.ok)throw Error('Atlas HTTP '+res.status);topo=await res.json();states=topojson.feature(topo,topo.objects.states).features;counties=topojson.feature(topo,topo.objects.counties).features;}catch(e){$('erStatus').textContent='Map boundaries unavailable: '+e.message}
  drawMap();})();return loadMapPromise}
 function drawMap(){
 const legend=document.querySelector('#resultsLab .er-legend');if(legend)legend.innerHTML=SWING_LEGEND;const svg=d3.select('#erMap');svg.selectAll('*').remove();if(!states.length){svg.append('text').attr('x',487).attr('y',305).attr('text-anchor','middle').attr('fill','#abc2dd').text('Map boundaries loading or unavailable');return;}
  const collection={type:'FeatureCollection',features:states},projection=d3.geoAlbersUsa().fitExtent([[16,18],[959,592]],collection),path=d3.geoPath(projection);
  const stateId=f=>reverse[String(f.id).padStart(2,'0')];
  let features=[],type='state';
  if(category==='house'){
   if(selectedState){features=districts.filter(f=>districtGeo(f).slice(0,2)===POSTAL[selectedState]);type='district';if(!features.length){features=states.filter(f=>String(f.id).padStart(2,'0')===POSTAL[selectedState]);type='state'}}
   else {features=districts.length?districts:states;type=districts.length?'district':'state'}
  }else if(selectedState){features=counties.filter(f=>String(f.id).padStart(5,'0').slice(0,2)===POSTAL[selectedState]);type='county'}
  else features=states;
  if(!features.length){svg.append('text').attr('x',487).attr('y',305).attr('text-anchor','middle').attr('fill','#abc2dd').text('Map geometry unavailable');return}
  const fit=selectedState?{type:'FeatureCollection',features:states.filter(f=>stateId(f)===selectedState)}:collection;
  if(selectedState&&fit.features.length)projection.fitExtent([[30,25],[945,585]],fit);
  const g=svg.append('g');
  g.selectAll('path').data(features).join('path').attr('d',path).attr('tabindex',0).attr('role','button')
   .attr('aria-label',f=>{if(type==='state')return nameState(stateId(f));if(type==='county')return f.properties?.name||'County';return f.properties?.NAME||districtGeo(f)||'District'})
   .attr('class',f=>{if(type==='state'&&!eligible(stateId(f)))return 'er-disabled';return ''})
   .attr('fill',f=>{
    if(type==='state'){const code=stateId(f);if(!eligible(code))return '#182638';const r=stateRaceResults(code);if(!r)return SWING_NO_DATA;return leader(summaryVotes(detailCache.get(r.id)||{})).color}
    if(type==='district'){const key=districtGeo(f);const r=raceForDistrict(key);return r?leader(summaryVotes(detailCache.get(r.id)||{})).color:SWING_NO_DATA}
    const region=getRegion(f);return region?leader(region.votes).color:SWING_NO_DATA;
   })
   .on('click',(e,f)=>handleFeature(type,f))
   .on('keydown',(e,f)=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();handleFeature(type,f)}})
   .append('title').text(f=>{const base=type==='state'?nameState(stateId(f)):type==='county'?(f.properties?.name||'County'):(f.properties?.NAME||districtGeo(f)||'District');let rp=null;{if(type==='state'){const code=stateId(f),r=eligible(code)?stateRaceResults(code):null;rp=r?raceReporting(detailCache.get(r.id)):null}else if(type==='county'){rp=getRegion(f)?.reporting||null}}const t=fmtReporting(rp);return t?base+'\n'+t+' reporting':base});
  if(selectedState){const outline=states.find(f=>stateId(f)===selectedState);if(outline)svg.append('path').attr('d',path(outline)).attr('fill','none').attr('stroke','#b9cce6').attr('stroke-width',1.4).style('pointer-events','none')}
  $('erMapTitle').textContent=(selectedState?nameState(selectedState)+' · County results':'United States · '+(category==='senate'?'Senate':'Governor')+' races');
  $('erBack').hidden=!selectedState;
 }
 async function handleFeature(type,f){if(type==='state'){
  const state=reverse[String(f.id).padStart(2,'0')];if(!state||!stateHasRace(state))return;selectedState=state;selectedCounty=null;selectedRace=stateRaceResults(state);drawMap();if(selectedRace)await fetchRace(selectedRace);render();return;
 }if(type==='district'){
  const key=districtGeo(f);const race=raceList().find(r=>districtKey(r)===key);selectedCounty=null;selectedState=reverse[key.slice(0,2)]||'';selectedRace=race||null;drawMap();if(race)await fetchRace(race);render();return;
 }if(type==='county'){
  selectedCounty=f;render();return;
 }}
 async function fetchRace(race,force=false){if(!race)return;const id=raceId(race);if(!id)return;if(!force&&detailCache.has(id))return;
  const token=++requestSeq;$('erStatus').textContent='Loading '+safe(race.title)+' from civicAPI…';try{const data=await request(API+'?mode=race&id='+encodeURIComponent(id)+(force?'&refresh='+Date.now():''));detailCache.set(id,data);$('erStatus').textContent='Connected · civicAPI · '+(new Date().toLocaleTimeString());}catch(e){$('erStatus').textContent='Race data unavailable: '+e.message}drawMap();render();}
 function raceCards(votes){if(!votes.length)return '<div class="er-empty">No candidate vote totals reported by civicAPI yet. This is not a zero-vote result.</div>';
  const ordered=[...votes].sort((a,b)=>b.votes-a.votes),total=ordered.reduce((a,c)=>a+c.votes,0);
  return ordered.map(c=>{const pct=total?100*c.votes/total:0;return '<div class="er-candidate"><div class="er-candline"><div><span class="er-dot" style="background:'+(tint[c.party]||tint.O)+'"></span><b>'+safe(c.name)+'</b><div class="er-sub">'+(c.party==='D'?'Democratic':c.party==='R'?'Republican':c.party==='O'?'Other / independent':c.party)+'</div></div><div style="text-align:right"><b>'+fmt(c.votes)+'</b><div class="er-sub">'+pct.toFixed(1)+'%</div></div></div><div class="er-track"><div class="er-fill" style="background:'+(tint[c.party]||tint.O)+';width:'+pct+'%"></div></div></div>'}).join('')}
 function showPopup(){let popup=$('erMapPopup');if(!popup){const map=$('erMap');popup=document.createElement('div');popup.id='erMapPopup';popup.className='er-popup';map.parentElement.style.position='relative';map.insertAdjacentElement('afterend',popup)}
  popup.hidden=true;return; // Candidate results are displayed in the dark results panel, not a white overlay.
  const raw=selectedRace?detailCache.get(raceId(selectedRace)):null;
  const region=selectedCounty?getRegion(selectedCounty):null;
  const votes=selectedCounty?(region?.votes||candidatesForRace(selectedRace,raw).map(c=>({...c,votes:0,reported:false}))):candidatesForRace(selectedRace,raw);
  const heading=selectedCounty?(selectedCounty.properties?.name||'County')+', '+nameState(selectedState):selectedRace?(selectedRace.title||nameState(selectedState)):nameState(selectedState);
  const scope=selectedCounty?'County results':'Statewide results';
  const margin=leader(votes),valid=votes.some(c=>c.reported);
  const items=votes.length?raceCards(votes):'';
  const multiple=!selectedCounty&&!selectedRace?stateRaceOptions(selectedState):[];
  popup.innerHTML='<div class="er-popuphead"><div><small>'+safe(scope)+'</small><h3>'+safe(heading)+'</h3></div><button type="button" id="erPopupClose" aria-label="Close results popup">×</button></div>'+
    (multiple.length?'<div class="er-popupselect">'+multiple.map(r=>'<button type="button" data-popup-race="'+safe(r.id)+'">'+safe(r.title||r.district||'Race')+' →</button>').join('')+'</div>':
    '<div class="er-popupmeta">'+(valid?fmt(votes.reduce((n,c)=>n+c.votes,0))+' votes · '+badge(margin):'Awaiting reported votes')+'</div>'+items);
  $('erPopupClose').onclick=()=>{selectedCounty=null;selectedRace=null;selectedState='';popup.hidden=true;drawMap();render()};
  popup.querySelectorAll('[data-popup-race]').forEach(b=>b.onclick=()=>{selectedRace=catalog.find(r=>r.id===b.dataset.popupRace);selectedCounty=null;fetchRace(selectedRace).then(render);render()});
 }
 function render(){if(root.hidden)return;
  document.querySelectorAll('#resultsLab [data-er-tab]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.erTab===category)));
  const races=raceList();$('erRaceCount').textContent=races.length?fmt(races.length)+' federal/statewide races in feed':catalogLoaded?'No matching races in civicAPI feed':'Awaiting race catalog';
  const options=[...new Set([...(category==='senate'?SENATE_2026:GOVERNOR_2026)])].sort((a,b)=>nameState(a).localeCompare(nameState(b)));
  const stateSelect=$('erState');stateSelect.innerHTML='<option value="">All states</option>'+options.map(c=>'<option value="'+c+'">'+nameState(c)+'</option>').join('');stateSelect.value=selectedState;
  $('erSearch').placeholder='Find state or race…';
  const filtered=races.filter(r=>!selectedState||getRaceState(r)===selectedState).filter(r=>(r.title+' '+r.district+' '+nameState(getRaceState(r))).toLowerCase().includes($('erSearch').value.toLowerCase())).sort((a,b)=>nameState(getRaceState(a)).localeCompare(nameState(getRaceState(b)))||a.title.localeCompare(b.title));
  $('erList').innerHTML=filtered.slice(0,600).map(r=>'<button type="button" data-er-id="'+safe(r.id)+'"><span>'+safe(nameState(getRaceState(r)))+' · '+safe(r.title||r.district||r.type)+'<small style="display:block;opacity:.72;margin-top:3px">'+safe(candidatesForRace(r,detailCache.get(r.id)).sort((a,b)=>b.votes-a.votes).map(c=>c.name).join(' · ')||'Candidate roster pending civicAPI')+'</small>'+reportingLine(r)+'</span><span class="er-chip">'+(detailCache.has(r.id)?'View':'Open')+'</span></button>').join('')||'<div class="er-empty">'+(catalogError?'Unable to load race catalog: '+safe(catalogError):catalogLoaded?'No matching races in the civicAPI catalog.':'Race catalog is loading. Results are not simulated.')+'</div>';
  $('erList').querySelectorAll('[data-er-id]').forEach(btn=>btn.onclick=()=>{const r=catalog.find(r=>r.id===btn.dataset.erId);if(!r)return;selectedRace=r;selectedCounty=null;selectedState=getRaceState(r);drawMap();fetchRace(r).then(render)});
  const raw=selectedRace?detailCache.get(raceId(selectedRace)):null,region=selectedCounty?getRegion(selectedCounty):null;
  const votes=selectedCounty?(region?.votes||candidatesForRace(selectedRace,raw).map(c=>({...c,votes:0,reported:false}))):candidatesForRace(selectedRace,raw),total=votes.reduce((a,c)=>a+c.votes,0),lead=leader(votes);
  $('erSelectionTitle').textContent=selectedCounty?(selectedCounty.properties?.name||'County')+' · '+nameState(selectedState):selectedRace?(selectedRace.title||nameState(selectedState)):category==='senate'?'United States Senate':'2026 Governors';
  $('erSelectionDesc').textContent=selectedCounty?'County-level results for the selected '+category+' race':selectedRace?'Statewide or districtwide candidate totals · '+nameState(selectedState):'Choose a state or race to inspect reported results.';
  $('erTotalVotes').textContent=raw&&votes.some(c=>c.reported)?fmt(total):'—';$('erMargin').textContent=raw&&total?badge(lead):'—';
  // Vote reporting: civicAPI-supplied values only.
  const rptKpi=$('erReportingKpi'),rptBox=$('erCountyReporting');
  if(rptBox){const wasOpen=!!rptBox.querySelector('details')?.open;
   {
    const rep=selectedCounty?(region?.reporting||null):raceReporting(raw);
    if($('erReportingLabel'))$('erReportingLabel').textContent=(selectedCounty?(selectedCounty.properties?.name||'County'):'Statewide')+' · vote reporting';
    if($('erReporting'))$('erReporting').textContent=fmtReporting(rep)||(selectedRace&&raw?'Not provided by civicAPI':'—');
    rptBox.innerHTML=countyReportingHtml(raw);if(wasOpen){const d=rptBox.querySelector('details');if(d)d.open=true}
   }}
  $('erCandidateList').innerHTML=selectedRace?(selectedCounty&&!region?'<div class="er-empty">County vote totals not yet provided by civicAPI for this race. Candidate names shown below are statewide roster only.</div>'+raceCards(votes):votes.length?raceCards(votes):'<div class="er-sub">Candidate roster not yet returned by the source.</div>'):'<div class="er-empty">No race selected. Choose a map area or race below.</div>';
  $('erCountyBack').hidden=!selectedCounty;showPopup();
  $('erSourceRace').href=selectedRace?'https://civicapi.org/results':'https://civicapi.org/results';
 }

 function setCategory(type){backgroundEpoch++;category=type;selectedState='';selectedRace=null;selectedCounty=null;$('erSearch').value='';drawMap();render();warmCategory()}
 function activate(){if(!window.__erInitialized){window.__erInitialized=true;
  document.querySelectorAll('#resultsLab [data-er-tab]').forEach(b=>b.onclick=()=>setCategory(b.dataset.erTab));
  $('erState').onchange=()=>{selectedState=$('erState').value;selectedCounty=null;selectedRace=selectedState?stateRaceResults(selectedState):null;drawMap();if(selectedRace)fetchRace(selectedRace);render()};
  $('erSearch').oninput=render;$('erBack').onclick=()=>{selectedState='';selectedRace=null;selectedCounty=null;drawMap();render()};
  $('erCountyBack').onclick=()=>{selectedCounty=null;render()};
  $('erRefresh').onclick=()=>{detailCache.clear();loadCatalog(true).then(()=>{if(selectedRace)fetchRace(selectedRace,true);drawMap()})};
  let catalogTick=0;
  refreshTimer=setInterval(async()=>{
   if(root.hidden||root.style.display==='none')return;
   // Keep the selected race current without reloading the entire race catalog.
   if(selectedRace)await fetchRace(selectedRace,true);
   // Refresh the visible map's cached returns in small batches, respecting API limits.
   const visible=raceList().filter(r=>selectedState?getRaceState(r)===selectedState:detailCache.has(r.id)).slice(0,18);
   for(const r of visible){if(selectedRace&&r.id===selectedRace.id)continue;
    try{detailCache.set(r.id,await request(API+'?mode=race&id='+encodeURIComponent(r.id)+'&refresh='+Date.now()))}catch(e){}
   }
   drawMap();render();$('erUpdated').textContent='Last results check '+new Date().toLocaleTimeString()+' · auto-refresh 30s';
   if(++catalogTick%10===0)loadCatalog(true);
  },30000);
  render();loadMaps();loadCatalog();
 }else{drawMap();render()}}
 window.activateProjectAmericaResults=activate;
 // Also activate after the lab selector changes; registration is independent of
 // the original inline script's initialization timing.
 document.getElementById('labSwitch')?.addEventListener('change',()=>{
   if(document.getElementById('labSwitch').value==='results')queueMicrotask(()=>{if(!root.hidden)activate()});
 });
 // The main page's inline controller runs before this deferred script. Initialize
 // independently when the results view is already selected on first load.
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{if(!root.hidden)activate()},{once:true});
 else if(!root.hidden)activate();
})();
