// Project America — Cloudflare Workers Static Assets + API Worker.
// This is the real Worker entry point. Deploy it together with ./public using Wrangler.
const CIVIC_API_BASE = "https://civicapi.org/api/v2";
const ELECTION_DATE = "2026-11-03";

// Explicit 2026 U.S. Senate race IDs supplied for Project America.
// Race details are always fetched live from civicAPI before vote totals are displayed.
const SENATE_IDS = {
  MI:"87214", NC:"87346", SC:"87409", GA:"87087", FL:"87068",
  AL:"86907", TN:"87475", MS:"81004", KY:"87174", WV:"87477",
  IL:"87129", IA:"87151", MN:"87229", AR:"86949", LA:"87183",
  OH:"87527", DE:"87036", NJ:"87302", RI:"87396", NH:"87283",
  ME:"87188", TX:"87438", OK:"87526", KS:"87162", NE:"87254",
  SD:"87446", MT:"87247", WY:"87496", CO:"87022", NM:"87288",
  ID:"87103", OR:"87374", AK:"86916", VA:"87472", MA:"87275"
};

const STATE_CODES = {
  ALABAMA:"AL", ALASKA:"AK", ARIZONA:"AZ", ARKANSAS:"AR",
  CALIFORNIA:"CA", COLORADO:"CO", CONNECTICUT:"CT", DELAWARE:"DE",
  FLORIDA:"FL", GEORGIA:"GA", HAWAII:"HI", IDAHO:"ID",
  ILLINOIS:"IL", INDIANA:"IN", IOWA:"IA", KANSAS:"KS",
  KENTUCKY:"KY", LOUISIANA:"LA", MAINE:"ME", MARYLAND:"MD",
  MASSACHUSETTS:"MA", MICHIGAN:"MI", MINNESOTA:"MN", MISSISSIPPI:"MS",
  MISSOURI:"MO", MONTANA:"MT", NEBRASKA:"NE", NEVADA:"NV",
  "NEW HAMPSHIRE":"NH", "NEW JERSEY":"NJ", "NEW MEXICO":"NM",
  "NEW YORK":"NY", "NORTH CAROLINA":"NC", "NORTH DAKOTA":"ND",
  OHIO:"OH", OKLAHOMA:"OK", OREGON:"OR", PENNSYLVANIA:"PA",
  "RHODE ISLAND":"RI", "SOUTH CAROLINA":"SC", "SOUTH DAKOTA":"SD",
  TENNESSEE:"TN", TEXAS:"TX", UTAH:"UT", VERMONT:"VT",
  VIRGINIA:"VA", WASHINGTON:"WA", "WEST VIRGINIA":"WV",
  WISCONSIN:"WI", WYOMING:"WY", "DISTRICT OF COLUMBIA":"DC"
};

const jsonHeaders = {
  "Content-Type":"application/json; charset=utf-8",
  "Cache-Control":"no-store"
};
const json = (body, status=200, extraHeaders={}) =>
  new Response(JSON.stringify(body), {status, headers:{...jsonHeaders, ...extraHeaders}});
const errorJson = (message, status=502, details={}) =>
  json({ok:false, error:String(message), ...details}, status);

function getRaceId(r) {
  return r?.race_id ?? r?.raceId ?? r?.raceid ?? r?.id ??
    r?.election_id ?? r?.electionId ?? r?.race?.id;
}

function findArrays(data, keys, depth=0) {
  if (!data || typeof data !== "object" || depth > 5) return [];
  if (Array.isArray(data)) return data;
  for (const key of keys) {
    if (Array.isArray(data[key])) return data[key];
  }
  for (const key of ["data","response","result","results","races","payload","election"]) {
    if (data[key] && typeof data[key] === "object") {
      const found = findArrays(data[key], keys, depth+1);
      if (found.length) return found;
    }
  }
  return [];
}

function raceType(r) {
  const text = [
    r?.office, r?.office_name, r?.race_name, r?.name, r?.title,
    r?.district, r?.election_name, r?.race_type, r?.office_type,
    r?.position, r?.position_name, r?.race?.name, r?.election?.name
  ].filter(Boolean).join(" ").toLowerCase();

  if (/\b(primary|runoff|state house|state representative|state senate|state senator|assembly|house of delegates|legislature)\b/.test(text)) return null;
  if (/\b(governor|gubernatorial)\b/.test(text) && !/\b(lieutenant|deputy)\s+governor\b/.test(text)) return "governor";
  if (/\b(u\.?s\.?|united states|federal)\s+(senate|senator)\b|\bu\.?s\.? senator\b/.test(text)) return "senate";
  if (/\bsenate\b/.test(text) && !/\b(state|provincial|legislative|assembly|primary)\b/.test(text)) return "senate";
  return null; // House results are intentionally excluded from Election Results.
}

function stateCode(r) {
  const candidates = [
    r?.province_code, r?.state_code, r?.state, r?.province,
    r?.location?.state, r?.location?.state_code,
    r?.jurisdiction?.state_code, r?.jurisdiction?.state
  ];
  for (const value of candidates) {
    const p = String(value ?? "").trim().toUpperCase();
    if (/^[A-Z]{2}$/.test(p)) return p;
    if (STATE_CODES[p]) return STATE_CODES[p];
    const usMatch = p.match(/(?:US|USA)[-_]([A-Z]{2})$/);
    if (usMatch) return usMatch[1];
  }
  const text = [
    r?.race_name, r?.name, r?.title, r?.office,
    r?.election_name, r?.district
  ].filter(Boolean).join(" ").toUpperCase();
  for (const [name, code] of Object.entries(STATE_CODES)) {
    if (new RegExp(`\\b${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`).test(text)) return code;
  }
  const codeMatch = text.match(/\b([A-Z]{2})\s+(?:U\.?S\.?\s+)?(?:SENATE|GOVERNOR)\b|\b(?:SENATE|GOVERNOR)[\s,-]+([A-Z]{2})\b/);
  return codeMatch ? (codeMatch[1] || codeMatch[2]) : null;
}

function raceRecord(r) {
  const id = getRaceId(r);
  const type = raceType(r);
  const state = stateCode(r);
  if (id == null || !type) return null;
  return {
    id:String(id),
    type,
    state,
    title:String(r?.race_name || r?.name || r?.title || r?.office || r?.election_name || ""),
    district:String(r?.district || r?.district_name || r?.district_number || r?.congressional_district || ""),
    raw:r
  };
}

async function fetchJson(url, timeoutMs=18000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort("upstream timeout"), timeoutMs);
  try {
    const response = await fetch(url, {
      signal:controller.signal,
      headers:{Accept:"application/json"}
    });
    const body = await response.text();
    let data;
    try {
      data = JSON.parse(body);
    } catch {
      const excerpt = body.replace(/\s+/g," ").slice(0,180);
      throw new Error(`Upstream returned non-JSON (HTTP ${response.status})${excerpt ? `: ${excerpt}` : ""}`);
    }
    if (!response.ok) {
      throw new Error(`civicAPI HTTP ${response.status}: ${data?.error || data?.message || response.statusText}`);
    }
    if (data?.error) throw new Error(String(data.error));
    return data;
  } finally {
    clearTimeout(timer);
  }
}

function searchUrl(params) {
  const url = new URL(`${CIVIC_API_BASE}/race/search`);
  for (const [key,value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== "") url.searchParams.set(key,String(value));
  }
  return url.toString();
}

async function discoverRaces() {
  const baseParams = {
    country:"US",
    start_date:ELECTION_DATE,
    end_date:ELECTION_DATE,
    limit:50000,
    offset:0
  };
  const primary = await fetchJson(searchUrl(baseParams));
  let rawRaces = findArrays(primary, ["races","results","items","elections"]);
  let source = "civicAPI date-scoped race search";

  // Some provider indexes omit statewide gubernatorial contests from the date query.
  // Make one focused supplemental query if no governor contests were found.
  if (!rawRaces.some(r => raceType(r) === "governor")) {
    try {
      const supplemental = await fetchJson(searchUrl({...baseParams, query:"governor"}));
      const extras = findArrays(supplemental, ["races","results","items","elections"]);
      const seen = new Set(rawRaces.map(r => String(getRaceId(r))));
      for (const item of extras) {
        const id = getRaceId(item);
        if (id != null && !seen.has(String(id))) {
          seen.add(String(id));
          rawRaces.push(item);
        }
      }
    } catch (e) {
      // A failed supplemental lookup does not discard a successful main catalog.
      source += `; governor supplement unavailable: ${e.message}`;
    }
  }

  const races = rawRaces.map(raceRecord).filter(Boolean);
  // Explicit user-supplied Senate race IDs take precedence over search metadata.
  for (const [state,id] of Object.entries(SENATE_IDS)) {
    const index = races.findIndex(r => r.type === "senate" && r.state === state);
    const known = {
      id, type:"senate", state, title:`${state} U.S. Senate`, district:"",
      raw:{id, source_page:`https://civicapi.org/results/elections/${id}`, configured:true}
    };
    if (index >= 0) races[index] = {...races[index], ...known};
    else races.push(known);
  }

  // Keep only the U.S. Senate and gubernatorial races in this results interface.
  const filtered = races.filter(r => r.type === "senate" || r.type === "governor");
  const senateIds = Object.entries(SENATE_IDS)
    .map(([state,id]) => ({state,id,title:`${state} U.S. Senate`}))
    .sort((a,b) => a.state.localeCompare(b.state));
  const governors = filtered.filter(r => r.type === "governor");
  return {
    date:ELECTION_DATE,
    source,
    races:filtered,
    senateIds,
    senateCount:senateIds.length,
    governorCount:governors.length,
    discovered:rawRaces.length,
    updated:new Date().toISOString(),
    warning:governors.length ? undefined : "civicAPI did not return any 2026 Governor contests in its catalog response. The configured Senate race list is available; Governor coverage needs provider verification."
  };
}

function configuredSenateFallback(error) {
  const senateIds = Object.entries(SENATE_IDS)
    .map(([state,id]) => ({state,id,title:`${state} U.S. Senate`}))
    .sort((a,b) => a.state.localeCompare(b.state));
  const races = senateIds.map(r => ({
    ...r, type:"senate", district:"",
    raw:{id:r.id, source_page:`https://civicapi.org/results/elections/${r.id}`, configured:true}
  }));
  return {
    date:ELECTION_DATE,
    source:"Project America configured CivicAPI Senate IDs",
    races, senateIds, senateCount:senateIds.length, governorCount:0,
    discovered:0,
    warning:`civicAPI catalog unavailable: ${error?.message || String(error)}. Senate entries are configured, but each race's live detail still needs to load from civicAPI.`,
    updated:new Date().toISOString()
  };
}

async function handleResults(request) {
  const url = new URL(request.url);
  const mode = url.searchParams.get("mode") || "catalog";

  if (mode === "health") {
    const checkedAt = new Date().toISOString();
    try {
      const upstream = await fetchJson(`${CIVIC_API_BASE}/status`, 10000);
      return json({ok:true, worker:"ok", civicAPI:{ok:true, status:upstream}, checkedAt});
    } catch (error) {
      // Distinguish Worker execution from upstream API health.
      return json({ok:true, worker:"ok", civicAPI:{ok:false, error:error.message}, checkedAt});
    }
  }

  if (mode === "race" || mode === "inspect") {
    const id = String(url.searchParams.get("id") || "");
    if (!/^\d{1,12}$/.test(id)) return errorJson("Invalid race ID", 400);
    try {
      const data = await fetchJson(`${CIVIC_API_BASE}/race/${encodeURIComponent(id)}`);
      return json(data);
    } catch (error) {
      return errorJson(`Unable to retrieve civicAPI race ${id}: ${error.message}`, 502, {raceId:id});
    }
  }

  if (mode === "senate-ids") {
    const ids = Object.entries(SENATE_IDS).map(([state,id])=>({state,id}));
    return json({ok:true, source:"configured user-supplied race IDs", senateIds:ids, count:ids.length, liveVerification:"not yet checked"});
  }

  if (mode !== "catalog") return errorJson("Unknown request mode", 400, {mode});

  try {
    return json(await discoverRaces());
  } catch (error) {
    // Return valid JSON and a clearly labelled configured Senate fallback.
    // The frontend must never mistake a failed catalog search for live discovery.
    return json(configuredSenateFallback(error));
  }
}

async function handleEarlyVote(request) {
  const url = new URL(request.url);
  const state = String(url.searchParams.get("state") || "").toUpperCase();
  const category = String(url.searchParams.get("category") || "").toLowerCase();
  if (!/^[A-Z]{2}$/.test(state)) return errorJson("A two-letter state code is required.", 400);
  if (!["requested","returned","inperson"].includes(category)) {
    return errorJson("Category must be requested, returned, or inperson.", 400);
  }
  const base = `${CIVIC_API_BASE}/early-vote/${encodeURIComponent(state)}/${encodeURIComponent(category)}`;
  try {
    let data;
    try {
      data = await fetchJson(base, 15000);
    } catch (firstError) {
      if (!String(firstError.message).includes("HTTP 404")) throw firstError;
      data = await fetchJson(`${CIVIC_API_BASE}/early-vote/${encodeURIComponent(state.toLowerCase())}/${encodeURIComponent(category)}`, 15000);
    }
    return json(data, 200, {"Cache-Control":"public, max-age=15, s-maxage=15"});
  } catch (error) {
    return errorJson(`civicAPI early-vote request failed: ${error.message}`, 502, {state,category});
  }
}

async function handleHouseBaseline() {
  const source = "https://docs.google.com/spreadsheets/d/1eZfaFI-c-PFOoKx1-zZA2MP0_dxRq_LVK0re3BOQqy0/export?format=csv&gid=1491069057";
  try {
    const response = await fetch(source, {redirect:"follow"});
    const body = await response.text();
    if (!response.ok) return new Response(body.slice(0,1000), {status:502, headers:{"Content-Type":"text/plain; charset=utf-8"}});
    if (body.length > 3000000) return new Response("House baseline too large", {status:502});
    return new Response(body, {status:200, headers:{
      "Content-Type":"text/csv; charset=utf-8",
      "Cache-Control":"public, max-age=3600, s-maxage=3600"
    }});
  } catch (error) {
    return new Response(`House baseline unavailable: ${error.message}`, {status:502});
  }
}

async function handleShare(request) {
  const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
  try {
    const url = new URL(request.url);
    const token = url.searchParams.get("d") || "";
    if (!/^[A-Za-z0-9_-]{1,12000}$/.test(token)) throw new Error("Invalid scenario token");
    const binary = atob(token.replace(/-/g,"+").replace(/_/g,"/"));
    if (binary.length > 9000) throw new Error("Scenario too large");
    const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
    const decompressed = new Response(
      new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"))
    );
    const raw = await decompressed.text();
    if (raw.length > 100000) throw new Error("Scenario too large");
    const obj = JSON.parse(raw);
    if (obj.v !== 1) throw new Error("Unsupported scenario");
    const label = String(obj.label || "Election scenario").slice(0,90);
    const margin = typeof obj.margin === "number" && Number.isFinite(obj.margin)
      ? `${obj.margin >= 0 ? "D" : "R"}+${Math.abs(obj.margin).toFixed(1)}`
      : "No results";
    const dem = Number.isFinite(Number(obj.d)) ? Number(obj.d).toLocaleString("en-US") : "—";
    const rep = Number.isFinite(Number(obj.rep)) ? Number(obj.rep).toLocaleString("en-US") : "—";
    const target = `${url.origin}/?scenario=${token}`;
    const title = `${label} · ${margin} | Project America`;
    const description = `Simulated two-party votes: D ${dem} · R ${rep}. Hypothetical scenario, not a forecast.`;
    return new Response(
      `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><meta property="og:type" content="website"><meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(description)}"><meta name="twitter:card" content="summary"><meta name="twitter:title" content="${esc(title)}"><meta name="twitter:description" content="${esc(description)}"><meta http-equiv="refresh" content="0;url=${esc(target)}"><link rel="canonical" href="${esc(target)}"></head><body><p><a href="${esc(target)}">Open Project America scenario</a></p></body></html>`,
      {status:200, headers:{"Content-Type":"text/html; charset=utf-8","Cache-Control":"public, max-age=300"}}
    );
  } catch (error) {
    return new Response(`Invalid scenario link: ${error.message}`, {status:400, headers:{"Content-Type":"text/plain; charset=utf-8"}});
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method !== "GET" && request.method !== "HEAD") {
      return errorJson("Only GET and HEAD requests are supported.", 405);
    }
    if (url.pathname === "/api/health") {
      return json({
        ok:true,
        worker:"project-america",
        staticAssetsBinding:Boolean(env?.ASSETS),
        time:new Date().toISOString(),
        apiRoutes:["/api/us-election-results","/api/early-vote","/api/house-baseline","/api/share"]
      });
    }
    if (url.pathname === "/api/us-election-results") return handleResults(request);
    if (url.pathname === "/api/early-vote") return handleEarlyVote(request);
    if (url.pathname === "/api/house-baseline") return handleHouseBaseline();
    if (url.pathname === "/api/share") return handleShare(request);

    if (!env?.ASSETS) {
      return new Response("Static asset binding ASSETS is missing. Deploy with the included wrangler.jsonc.", {
        status:500, headers:{"Content-Type":"text/plain; charset=utf-8"}
      });
    }
    return env.ASSETS.fetch(request);
  }
};
