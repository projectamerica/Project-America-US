// Vercel catch-all API function. Reuses the same Project America backend logic.
import worker from "../src/index.js";

export const config = { runtime: "nodejs" };

export default async function handler(req, res) {
  try {
    const protocol = (req.headers["x-forwarded-proto"] || "https").split(",")[0];
    const host = req.headers.host || "localhost";
    const url = new URL(req.url || "/", `${protocol}://${host}`);
    const request = new Request(url, { method: req.method || "GET", headers: req.headers });
    // All /api routes are handled before the static-assets binding is needed.
    const response = await worker.fetch(request, {});
    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));
    if (req.method === "HEAD" || response.status === 204 || response.status === 304) return res.end();
    const body = Buffer.from(await response.arrayBuffer());
    return res.send(body);
  } catch (error) {
    return res.status(500).json({ ok: false, error: error?.message || "Internal server error" });
  }
}
